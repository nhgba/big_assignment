/* =====================================================
   CSDL: ThueTro  (SQL Server / T-SQL, SSMS 22)
   Đề tài: Website thuê trọ - Jakarta EE (EJB + JSF)
   ===================================================== */
USE master;
GO
IF DB_ID(N'ThueTro') IS NOT NULL
BEGIN
    ALTER DATABASE ThueTro SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE ThueTro;
END
GO
CREATE DATABASE ThueTro COLLATE Vietnamese_CI_AS;
GO
USE ThueTro;
GO

/* ---------- 1. Người dùng (đăng ký / đăng nhập, phân quyền) ---------- */
CREATE TABLE NguoiDung (
    MaND        INT IDENTITY(1,1) PRIMARY KEY,
    TenDangNhap VARCHAR(50)    NOT NULL UNIQUE,
    MatKhau     VARCHAR(100)   NOT NULL,          -- lưu hash SHA-256 (hex)
    HoTen       NVARCHAR(100)  NOT NULL,
    Email       VARCHAR(100)   NOT NULL UNIQUE,
    SoDienThoai VARCHAR(15)    NULL,
    VaiTro      VARCHAR(10)    NOT NULL DEFAULT 'KHACH'
                CHECK (VaiTro IN ('ADMIN','KHACH')),
    NgayTao     DATETIME       NOT NULL DEFAULT GETDATE()
);

/* ---------- 2. Khu vực (danh mục quản lý #1) ---------- */
CREATE TABLE KhuVuc (
    MaKV    INT IDENTITY(1,1) PRIMARY KEY,
    TenKV   NVARCHAR(100) NOT NULL UNIQUE,
    MoTa    NVARCHAR(300) NULL
);

/* ---------- 3. Loại phòng (danh mục quản lý #2) ---------- */
CREATE TABLE LoaiPhong (
    MaLoai  INT IDENTITY(1,1) PRIMARY KEY,
    TenLoai NVARCHAR(100) NOT NULL UNIQUE,
    MoTa    NVARCHAR(300) NULL
);

/* ---------- 4. Phòng trọ (danh mục quản lý #3) ---------- */
CREATE TABLE Phong (
    MaPhong   INT IDENTITY(1,1) PRIMARY KEY,
    TenPhong  NVARCHAR(150) NOT NULL,
    MaKV      INT NOT NULL REFERENCES KhuVuc(MaKV),
    MaLoai    INT NOT NULL REFERENCES LoaiPhong(MaLoai),
    DiaChi    NVARCHAR(250) NOT NULL,
    DienTich  DECIMAL(6,2)  NOT NULL CHECK (DienTich > 0),
    GiaThue   DECIMAL(12,0) NOT NULL CHECK (GiaThue > 0),   -- VNĐ/tháng
    MoTa      NVARCHAR(1000) NULL,
    HinhAnh   NVARCHAR(255) NULL,       -- tên file ảnh admin upload
    TrangThai VARCHAR(10) NOT NULL DEFAULT 'CON'
              CHECK (TrangThai IN ('CON','DATHUE')),
    NgayDang  DATETIME NOT NULL DEFAULT GETDATE()
);

/* ---------- 5. Đơn thuê (giỏ hàng -> đơn) ---------- */
CREATE TABLE DonThue (
    MaDon        INT IDENTITY(1,1) PRIMARY KEY,
    MaND         INT NOT NULL REFERENCES NguoiDung(MaND),
    NgayDat      DATETIME NOT NULL DEFAULT GETDATE(),
    HoTenNguoiThue NVARCHAR(100) NOT NULL,
    SoDienThoai  VARCHAR(15)   NOT NULL,
    DiaChiLienHe NVARCHAR(250) NULL,
    PhuongThucTT NVARCHAR(50)  NOT NULL DEFAULT N'Tiền mặt',
    GhiChu       NVARCHAR(300) NULL,
    TongTien     DECIMAL(14,0) NOT NULL DEFAULT 0,
    TrangThai    VARCHAR(12) NOT NULL DEFAULT 'CHOXACNHAN'
                 CHECK (TrangThai IN ('CHOXACNHAN','DAXACNHAN','DAHUY'))
);

CREATE TABLE ChiTietDonThue (
    MaCT      INT IDENTITY(1,1) PRIMARY KEY,
    MaDon     INT NOT NULL REFERENCES DonThue(MaDon) ON DELETE CASCADE,
    MaPhong   INT NOT NULL REFERENCES Phong(MaPhong),
    SoThang   INT NOT NULL CHECK (SoThang > 0),
    DonGia    DECIMAL(12,0) NOT NULL,           -- giá tại thời điểm thuê
    ThanhTien AS (SoThang * DonGia) PERSISTED
);

/* ---------- 6. Góp ý ---------- */
CREATE TABLE GopY (
    MaGY    INT IDENTITY(1,1) PRIMARY KEY,
    MaND    INT NULL REFERENCES NguoiDung(MaND),
    MaPhong INT NULL REFERENCES Phong(MaPhong),
    HoTen   NVARCHAR(100) NOT NULL,
    Email   VARCHAR(100)  NULL,
    NoiDung NVARCHAR(1000) NOT NULL,
    NgayGui DATETIME NOT NULL DEFAULT GETDATE()
);
GO

/* ---------- Chỉ mục phục vụ tìm kiếm ---------- */
CREATE INDEX IX_Phong_TenPhong ON Phong(TenPhong);
CREATE INDEX IX_Phong_KV_Loai  ON Phong(MaKV, MaLoai);
CREATE INDEX IX_DonThue_MaND   ON DonThue(MaND);
GO

/* =====================================================
   DỮ LIỆU MẪU
   Mật khẩu mẫu: admin123 / khach123  (SHA-256, chữ thường)
   ===================================================== */
INSERT INTO NguoiDung (TenDangNhap, MatKhau, HoTen, Email, SoDienThoai, VaiTro) VALUES
('admin',  LOWER(CONVERT(VARCHAR(64), HASHBYTES('SHA2_256','admin123'),2)),
 N'Quản trị viên', 'admin@thuetro.vn', '0900000001', 'ADMIN'),
('khach1', LOWER(CONVERT(VARCHAR(64), HASHBYTES('SHA2_256','khach123'),2)),
 N'Nguyễn Văn An', 'an@gmail.com', '0900000002', 'KHACH');

INSERT INTO KhuVuc (TenKV, MoTa) VALUES
(N'Ninh Kiều',  N'Trung tâm thành phố Cần Thơ, gần các trường đại học'),
(N'Cái Răng',   N'Khu vực chợ nổi, giao thông thuận tiện'),
(N'Bình Thủy',  N'Yên tĩnh, gần Đại học Y Dược'),
(N'Vĩnh Thạnh',N'Ngoại ô, giá thuê thấp');

INSERT INTO LoaiPhong (TenLoai, MoTa) VALUES
(N'Phòng trọ thường', N'Phòng đơn, WC chung hoặc riêng'),
(N'Phòng khép kín',   N'Có WC và bếp riêng'),
(N'Căn hộ mini',      N'Đầy đủ nội thất cơ bản'),
(N'Ký túc xá tư nhân',N'Ở ghép, giá rẻ');

INSERT INTO Phong (TenPhong, MaKV, MaLoai, DiaChi, DienTich, GiaThue, MoTa, HinhAnh, TrangThai) VALUES
(N'Phòng trọ gần ĐH Cần Thơ', 1, 1, N'12 đường 3/2, Ninh Kiều', 20, 1500000, N'Thoáng mát, có máy lạnh, gần trường.', NULL, 'CON'),
(N'Phòng khép kín Xuân Khánh', 1, 2, N'45 Nguyễn Văn Cừ, Ninh Kiều', 25, 2300000, N'WC riêng, bếp nhỏ, có chỗ để xe.', NULL, 'CON'),
(N'Căn hộ mini Cái Răng',       2, 3, N'88 Võ Nguyên Giáp, Cái Răng', 35, 3500000, N'Nội thất cơ bản, ban công.', NULL, 'CON'),
(N'Phòng trọ Bình Thủy yên tĩnh', 3, 1, N'20 Lê Hồng Phong, Bình Thủy', 18, 1200000, N'An ninh tốt, giờ giấc tự do.', NULL, 'CON'),
(N'KTX tư nhân Vĩnh Thạnh',     4, 4, N'Thị trấn Vĩnh Thạnh', 40, 600000, N'Ở ghép 4 người, có wifi.', NULL, 'CON'),
(N'Phòng khép kín Cái Răng',    2, 2, N'15 Trần Hoàng Na, Cái Răng', 22, 2000000, N'Mới xây, sạch sẽ.', NULL, 'CON');

INSERT INTO GopY (MaND, HoTen, Email, NoiDung) VALUES
(2, N'Nguyễn Văn An', 'an@gmail.com', N'Website dễ dùng, mong có thêm ảnh phòng.');
GO

/* Kiểm tra nhanh */
SELECT p.MaPhong, p.TenPhong, kv.TenKV, lp.TenLoai, p.GiaThue
FROM Phong p JOIN KhuVuc kv ON p.MaKV=kv.MaKV JOIN LoaiPhong lp ON p.MaLoai=lp.MaLoai;
GO
