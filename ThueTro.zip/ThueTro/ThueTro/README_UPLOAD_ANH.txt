HUONG DAN CAP NHAT CHUC NANG UPLOAD ANH - THUETRO

1. Mo project ThueTro bang NetBeans.
2. Chon Clean and Build project tong (EAR), sau do Deploy lai.
3. Vao Quan ly phong tro, bam Chon tep va chon anh JPG/JPEG/PNG/GIF/WEBP (toi da 5 MB).
4. Khi luu thanh cong, anh duoc luu tai:
   - Windows: %USERPROFILE%\\ThueTroUploads
   - macOS/Linux: <user.home>/ThueTroUploads
5. Database Phong.HinhAnh luu duong dan tuong doi dang uploaded-images/<ten-anh>.
6. Anh duoc hien thi tai trang quan ly, trang chu va trang chi tiet phong.
7. Khi sua phong va khong chon anh moi, anh cu duoc giu lai.

Luu y:
- Khong can sua SQL/database; cot Phong.HinhAnh da co trong ThueTro.sql.
- Tai khoan Windows chay GlassFish can co quyen ghi vao thu muc ThueTroUploads trong user.home.
- Thu muc build/dist cu da duoc loai khoi goi ZIP de NetBeans tao lai tu ma nguon moi, tranh dung JSP/class cu.
