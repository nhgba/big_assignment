package sbeans;

import ebeans.LoaiPhong;
import jakarta.ejb.Local;
import java.util.List;

@Local
public interface LoaiPhongFacadeLocal {
    void create(LoaiPhong loaiPhong);
    void edit(LoaiPhong loaiPhong);
    void remove(LoaiPhong loaiPhong);
    LoaiPhong find(Object id);
    List<LoaiPhong> findAll();
    List<LoaiPhong> searchByName(String keyword);
}
