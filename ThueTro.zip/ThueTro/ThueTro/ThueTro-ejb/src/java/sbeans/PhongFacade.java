package sbeans;

import ebeans.Phong;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;

@Stateless
public class PhongFacade extends AbstractFacade<Phong> implements PhongFacadeLocal {
    @PersistenceContext(unitName = "ThueTroPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() { return em; }

    public PhongFacade() { super(Phong.class); }

    @Override
    public List<Phong> searchPhong(String keyword, Integer maKV, Integer maLoai, String trangThai) {
        StringBuilder jpql = new StringBuilder("SELECT p FROM Phong p WHERE 1=1");
        if (keyword != null && !keyword.trim().isEmpty()) {
            jpql.append(" AND (p.tenPhong LIKE :kw OR p.diaChi LIKE :kw)");
        }
        if (maKV != null && maKV > 0) {
            jpql.append(" AND p.maKV.maKV = :maKV");
        }
        if (maLoai != null && maLoai > 0) {
            jpql.append(" AND p.maLoai.maLoai = :maLoai");
        }
        if (trangThai != null && !trangThai.trim().isEmpty()) {
            jpql.append(" AND p.trangThai = :trangThai");
        }
        jpql.append(" ORDER BY p.ngayDang DESC");

        TypedQuery<Phong> query = em.createQuery(jpql.toString(), Phong.class);
        if (keyword != null && !keyword.trim().isEmpty()) {
            query.setParameter("kw", "%" + keyword.trim() + "%");
        }
        if (maKV != null && maKV > 0) {
            query.setParameter("maKV", maKV);
        }
        if (maLoai != null && maLoai > 0) {
            query.setParameter("maLoai", maLoai);
        }
        if (trangThai != null && !trangThai.trim().isEmpty()) {
            query.setParameter("trangThai", trangThai);
        }
        return query.getResultList();
    }
}
