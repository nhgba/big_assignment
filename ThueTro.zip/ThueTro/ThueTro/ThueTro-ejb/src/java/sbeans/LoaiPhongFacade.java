package sbeans;

import ebeans.LoaiPhong;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class LoaiPhongFacade extends AbstractFacade<LoaiPhong> implements LoaiPhongFacadeLocal {
    @PersistenceContext(unitName = "ThueTroPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() { return em; }

    public LoaiPhongFacade() { super(LoaiPhong.class); }

    @Override
    public List<LoaiPhong> searchByName(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return em.createNamedQuery("LoaiPhong.findAll", LoaiPhong.class).getResultList();
        }
        return em.createQuery("SELECT l FROM LoaiPhong l WHERE l.tenLoai LIKE :kw OR l.moTa LIKE :kw ORDER BY l.maLoai DESC", LoaiPhong.class)
                 .setParameter("kw", "%" + keyword.trim() + "%")
                 .getResultList();
    }
}
