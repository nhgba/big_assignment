package sbeans;

import ebeans.Phong;
import jakarta.ejb.Local;
import java.util.List;

@Local
public interface PhongFacadeLocal {
    void create(Phong phong);
    void edit(Phong phong);
    void remove(Phong phong);
    Phong find(Object id);
    List<Phong> findAll();
    List<Phong> searchPhong(String keyword, Integer maKV, Integer maLoai, String trangThai);
}
