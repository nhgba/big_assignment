package sbeans;

import ebeans.DonThue;
import jakarta.ejb.Local;
import java.util.List;

@Local
public interface DonThueFacadeLocal {
    void create(DonThue donThue);
    void edit(DonThue donThue);
    void remove(DonThue donThue);
    DonThue find(Object id);
    List<DonThue> findAll();
    List<DonThue> findAllOrderByDate();
    List<DonThue> findByUser(Integer maND);
    void xacNhanDonThue(Integer maDon);
    void huyDonThue(Integer maDon);
}
