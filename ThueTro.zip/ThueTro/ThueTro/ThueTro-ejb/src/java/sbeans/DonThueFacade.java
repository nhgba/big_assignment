package sbeans;

import ebeans.ChiTietDonThue;
import ebeans.DonThue;
import ebeans.Phong;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class DonThueFacade extends AbstractFacade<DonThue> implements DonThueFacadeLocal {
    @PersistenceContext(unitName = "ThueTroPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() { return em; }

    public DonThueFacade() { super(DonThue.class); }

    @Override
    public List<DonThue> findAllOrderByDate() {
        return em.createNamedQuery("DonThue.findAll", DonThue.class).getResultList();
    }

    @Override
    public List<DonThue> findByUser(Integer maND) {
        return em.createQuery("SELECT d FROM DonThue d WHERE d.maND.maND = :maND ORDER BY d.ngayDat DESC", DonThue.class)
                 .setParameter("maND", maND)
                 .getResultList();
    }

    @Override
    public void xacNhanDonThue(Integer maDon) {
        DonThue don = em.find(DonThue.class, maDon);
        if (don != null && "CHOXACNHAN".equals(don.getTrangThai())) {
            don.setTrangThai("DAXACNHAN");
            em.merge(don);
            if (don.getChiTietDonThueList() != null) {
                for (ChiTietDonThue ct : don.getChiTietDonThueList()) {
                    Phong p = ct.getMaPhong();
                    if (p != null) {
                        p.setTrangThai("DATHUE");
                        em.merge(p);
                    }
                }
            }
        }
    }

    @Override
    public void huyDonThue(Integer maDon) {
        DonThue don = em.find(DonThue.class, maDon);
        if (don != null && "CHOXACNHAN".equals(don.getTrangThai())) {
            don.setTrangThai("DAHUY");
            em.merge(don);
        }
    }
}
