package sbeans;

import ebeans.KhuVuc;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class KhuVucFacade extends AbstractFacade<KhuVuc> implements KhuVucFacadeLocal {
    @PersistenceContext(unitName = "ThueTroPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() { return em; }

    public KhuVucFacade() { super(KhuVuc.class); }

    @Override
    public List<KhuVuc> searchByName(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return em.createNamedQuery("KhuVuc.findAll", KhuVuc.class).getResultList();
        }
        return em.createQuery("SELECT k FROM KhuVuc k WHERE k.tenKV LIKE :kw OR k.moTa LIKE :kw ORDER BY k.maKV DESC", KhuVuc.class)
                 .setParameter("kw", "%" + keyword.trim() + "%")
                 .getResultList();
    }
}
