package sbeans;

import ebeans.NguoiDung;
import jakarta.ejb.Local;
import java.util.List;

@Local
public interface NguoiDungFacadeLocal {
    void create(NguoiDung nguoiDung);
    void edit(NguoiDung nguoiDung);
    void remove(NguoiDung nguoiDung);
    NguoiDung find(Object id);
    List<NguoiDung> findAll();
    NguoiDung login(String tenDangNhap, String matKhauHash);
    boolean existsUsername(String username);
    boolean existsEmail(String email);
}
