package sbeans;

import ebeans.GopY;
import jakarta.ejb.Local;
import java.util.List;

@Local
public interface GopYFacadeLocal {
    void create(GopY gopY);
    void edit(GopY gopY);
    void remove(GopY gopY);
    GopY find(Object id);
    List<GopY> findAll();
    List<GopY> findByPhong(Integer maPhong);
}
