package sbeans;

import ebeans.NguoiDung;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceContext;

@Stateless
public class NguoiDungFacade extends AbstractFacade<NguoiDung> implements NguoiDungFacadeLocal {
    @PersistenceContext(unitName = "ThueTroPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() { return em; }

    public NguoiDungFacade() { super(NguoiDung.class); }

    @Override
    public NguoiDung login(String tenDangNhap, String matKhauHash) {
        try {
            return em.createQuery("SELECT n FROM NguoiDung n WHERE n.tenDangNhap = :u AND n.matKhau = :p", NguoiDung.class)
                     .setParameter("u", tenDangNhap)
                     .setParameter("p", matKhauHash)
                     .getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Override
    public boolean existsUsername(String username) {
        Long count = em.createQuery("SELECT COUNT(n) FROM NguoiDung n WHERE n.tenDangNhap = :u", Long.class)
                       .setParameter("u", username)
                       .getSingleResult();
        return count > 0;
    }

    @Override
    public boolean existsEmail(String email) {
        Long count = em.createQuery("SELECT COUNT(n) FROM NguoiDung n WHERE n.email = :e", Long.class)
                       .setParameter("e", email)
                       .getSingleResult();
        return count > 0;
    }
}
