package sbeans;

import ebeans.KhuVuc;
import jakarta.ejb.Local;
import java.util.List;

@Local
public interface KhuVucFacadeLocal {
    void create(KhuVuc khuVuc);
    void edit(KhuVuc khuVuc);
    void remove(KhuVuc khuVuc);
    KhuVuc find(Object id);
    List<KhuVuc> findAll();
    List<KhuVuc> searchByName(String keyword);
}
