package sbeans;

import ebeans.GopY;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class GopYFacade extends AbstractFacade<GopY> implements GopYFacadeLocal {
    @PersistenceContext(unitName = "ThueTroPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() { return em; }

    public GopYFacade() { super(GopY.class); }

    @Override
    public List<GopY> findByPhong(Integer maPhong) {
        return em.createQuery("SELECT g FROM GopY g WHERE g.maPhong.maPhong = :maPhong ORDER BY g.ngayGui DESC", GopY.class)
                 .setParameter("maPhong", maPhong)
                 .getResultList();
    }
}
