package ebeans;

import jakarta.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

@Entity
@Table(name = "ChiTietDonThue")
public class ChiTietDonThue implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MaCT")
    private Integer maCT;

    @JoinColumn(name = "MaDon", referencedColumnName = "MaDon", nullable = false)
    @ManyToOne(optional = false)
    private DonThue maDon;

    @JoinColumn(name = "MaPhong", referencedColumnName = "MaPhong", nullable = false)
    @ManyToOne(optional = false)
    private Phong maPhong;

    @Column(name = "SoThang", nullable = false)
    private int soThang;

    @Column(name = "DonGia", nullable = false, precision = 12, scale = 0)
    private BigDecimal donGia;

    @Column(name = "ThanhTien", insertable = false, updatable = false, precision = 14, scale = 0)
    private BigDecimal thanhTien;

    public ChiTietDonThue() {}

    public Integer getMaCT() { return maCT; }
    public void setMaCT(Integer maCT) { this.maCT = maCT; }
    public DonThue getMaDon() { return maDon; }
    public void setMaDon(DonThue maDon) { this.maDon = maDon; }
    public Phong getMaPhong() { return maPhong; }
    public void setMaPhong(Phong maPhong) { this.maPhong = maPhong; }
    public int getSoThang() { return soThang; }
    public void setSoThang(int soThang) { this.soThang = soThang; }
    public BigDecimal getDonGia() { return donGia; }
    public void setDonGia(BigDecimal donGia) { this.donGia = donGia; }
    public BigDecimal getThanhTien() {
        if (thanhTien != null) return thanhTien;
        return donGia != null ? donGia.multiply(BigDecimal.valueOf(soThang)) : BigDecimal.ZERO;
    }
}
