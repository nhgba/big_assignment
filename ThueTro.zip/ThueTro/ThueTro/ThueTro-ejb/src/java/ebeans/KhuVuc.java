package ebeans;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "KhuVuc")
@NamedQueries({
    @NamedQuery(name = "KhuVuc.findAll", query = "SELECT k FROM KhuVuc k ORDER BY k.maKV DESC")
})
public class KhuVuc implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MaKV")
    private Integer maKV;

    @Column(name = "TenKV", nullable = false, unique = true, length = 100)
    private String tenKV;

    @Column(name = "MoTa", length = 300)
    private String moTa;

    @OneToMany(mappedBy = "maKV")
    private List<Phong> phongList;

    public KhuVuc() {}

    public Integer getMaKV() { return maKV; }
    public void setMaKV(Integer maKV) { this.maKV = maKV; }
    public String getTenKV() { return tenKV; }
    public void setTenKV(String tenKV) { this.tenKV = tenKV; }
    public String getMoTa() { return moTa; }
    public void setMoTa(String moTa) { this.moTa = moTa; }
    public List<Phong> getPhongList() { return phongList; }
    public void setPhongList(List<Phong> phongList) { this.phongList = phongList; }
}
