package ebeans;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "GopY")
public class GopY implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MaGY")
    private Integer maGY;

    @JoinColumn(name = "MaND", referencedColumnName = "MaND")
    @ManyToOne
    private NguoiDung maND;

    @JoinColumn(name = "MaPhong", referencedColumnName = "MaPhong")
    @ManyToOne
    private Phong maPhong;

    @Column(name = "HoTen", nullable = false, length = 100)
    private String hoTen;

    @Column(name = "Email", length = 100)
    private String email;

    @Column(name = "NoiDung", nullable = false, length = 1000)
    private String noiDung;

    @Column(name = "NgayGui", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date ngayGui = new Date();

    public GopY() {}

    public Integer getMaGY() { return maGY; }
    public void setMaGY(Integer maGY) { this.maGY = maGY; }
    public NguoiDung getMaND() { return maND; }
    public void setMaND(NguoiDung maND) { this.maND = maND; }
    public Phong getMaPhong() { return maPhong; }
    public void setMaPhong(Phong maPhong) { this.maPhong = maPhong; }
    public String getHoTen() { return hoTen; }
    public void setHoTen(String hoTen) { this.hoTen = hoTen; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getNoiDung() { return noiDung; }
    public void setNoiDung(String noiDung) { this.noiDung = noiDung; }
    public Date getNgayGui() { return ngayGui; }
    public void setNgayGui(Date ngayGui) { this.ngayGui = ngayGui; }
}
