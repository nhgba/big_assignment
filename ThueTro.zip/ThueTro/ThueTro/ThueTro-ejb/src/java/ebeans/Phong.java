package ebeans;

import jakarta.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "Phong")
@NamedQueries({
    @NamedQuery(name = "Phong.findAll", query = "SELECT p FROM Phong p ORDER BY p.ngayDang DESC")
})
public class Phong implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MaPhong")
    private Integer maPhong;

    @Column(name = "TenPhong", nullable = false, length = 150)
    private String tenPhong;

    @JoinColumn(name = "MaKV", referencedColumnName = "MaKV", nullable = false)
    @ManyToOne(optional = false)
    private KhuVuc maKV;

    @JoinColumn(name = "MaLoai", referencedColumnName = "MaLoai", nullable = false)
    @ManyToOne(optional = false)
    private LoaiPhong maLoai;

    @Column(name = "DiaChi", nullable = false, length = 250)
    private String diaChi;

    @Column(name = "DienTich", nullable = false, precision = 6, scale = 2)
    private BigDecimal dienTich;

    @Column(name = "GiaThue", nullable = false, precision = 12, scale = 0)
    private BigDecimal giaThue;

    @Column(name = "MoTa", length = 1000)
    private String moTa;

    @Column(name = "HinhAnh", length = 255)
    private String hinhAnh;

    @Column(name = "TrangThai", nullable = false, length = 10)
    private String trangThai = "CON";

    @Column(name = "NgayDang", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date ngayDang = new Date();

    @OneToMany(mappedBy = "maPhong")
    private List<GopY> gopYList;

    public Phong() {}

    public Integer getMaPhong() { return maPhong; }
    public void setMaPhong(Integer maPhong) { this.maPhong = maPhong; }
    public String getTenPhong() { return tenPhong; }
    public void setTenPhong(String tenPhong) { this.tenPhong = tenPhong; }
    public KhuVuc getMaKV() { return maKV; }
    public void setMaKV(KhuVuc maKV) { this.maKV = maKV; }
    public LoaiPhong getMaLoai() { return maLoai; }
    public void setMaLoai(LoaiPhong maLoai) { this.maLoai = maLoai; }
    public String getDiaChi() { return diaChi; }
    public void setDiaChi(String diaChi) { this.diaChi = diaChi; }
    public BigDecimal getDienTich() { return dienTich; }
    public void setDienTich(BigDecimal dienTich) { this.dienTich = dienTich; }
    public BigDecimal getGiaThue() { return giaThue; }
    public void setGiaThue(BigDecimal giaThue) { this.giaThue = giaThue; }
    public String getMoTa() { return moTa; }
    public void setMoTa(String moTa) { this.moTa = moTa; }
    public String getHinhAnh() { return hinhAnh; }
    public void setHinhAnh(String hinhAnh) { this.hinhAnh = hinhAnh; }
    public String getTrangThai() { return trangThai; }
    public void setTrangThai(String trangThai) { this.trangThai = trangThai; }
    public Date getNgayDang() { return ngayDang; }
    public void setNgayDang(Date ngayDang) { this.ngayDang = ngayDang; }
    public List<GopY> getGopYList() { return gopYList; }
    public void setGopYList(List<GopY> gopYList) { this.gopYList = gopYList; }
}
