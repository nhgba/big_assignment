package ebeans;

import jakarta.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "DonThue")
@NamedQueries({
    @NamedQuery(name = "DonThue.findAll", query = "SELECT d FROM DonThue d ORDER BY d.ngayDat DESC")
})
public class DonThue implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MaDon")
    private Integer maDon;

    @JoinColumn(name = "MaND", referencedColumnName = "MaND", nullable = false)
    @ManyToOne(optional = false)
    private NguoiDung maND;

    @Column(name = "NgayDat", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date ngayDat = new Date();

    @Column(name = "HoTenNguoiThue", nullable = false, length = 100)
    private String hoTenNguoiThue;

    @Column(name = "SoDienThoai", nullable = false, length = 15)
    private String soDienThoai;

    @Column(name = "DiaChiLienHe", length = 250)
    private String diaChiLienHe;

    @Column(name = "PhuongThucTT", nullable = false, length = 50)
    private String phuongThucTT = "Tiền mặt";

    @Column(name = "GhiChu", length = 300)
    private String ghiChu;

    @Column(name = "TongTien", nullable = false, precision = 14, scale = 0)
    private BigDecimal tongTien = BigDecimal.ZERO;

    @Column(name = "TrangThai", nullable = false, length = 12)
    private String trangThai = "CHOXACNHAN";

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "maDon", fetch = FetchType.EAGER)
    private List<ChiTietDonThue> chiTietDonThueList;

    public DonThue() {}

    public Integer getMaDon() { return maDon; }
    public void setMaDon(Integer maDon) { this.maDon = maDon; }
    public NguoiDung getMaND() { return maND; }
    public void setMaND(NguoiDung maND) { this.maND = maND; }
    public Date getNgayDat() { return ngayDat; }
    public void setNgayDat(Date ngayDat) { this.ngayDat = ngayDat; }
    public String getHoTenNguoiThue() { return hoTenNguoiThue; }
    public void setHoTenNguoiThue(String hoTenNguoiThue) { this.hoTenNguoiThue = hoTenNguoiThue; }
    public String getSoDienThoai() { return soDienThoai; }
    public void setSoDienThoai(String soDienThoai) { this.soDienThoai = soDienThoai; }
    public String getDiaChiLienHe() { return diaChiLienHe; }
    public void setDiaChiLienHe(String diaChiLienHe) { this.diaChiLienHe = diaChiLienHe; }
    public String getPhuongThucTT() { return phuongThucTT; }
    public void setPhuongThucTT(String phuongThucTT) { this.phuongThucTT = phuongThucTT; }
    public String getGhiChu() { return ghiChu; }
    public void setGhiChu(String ghiChu) { this.ghiChu = ghiChu; }
    public BigDecimal getTongTien() { return tongTien; }
    public void setTongTien(BigDecimal tongTien) { this.tongTien = tongTien; }
    public String getTrangThai() { return trangThai; }
    public void setTrangThai(String trangThai) { this.trangThai = trangThai; }
    public List<ChiTietDonThue> getChiTietDonThueList() { return chiTietDonThueList; }
    public void setChiTietDonThueList(List<ChiTietDonThue> chiTietDonThueList) { this.chiTietDonThueList = chiTietDonThueList; }
}
