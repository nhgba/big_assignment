package ebeans;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "LoaiPhong")
@NamedQueries({
    @NamedQuery(name = "LoaiPhong.findAll", query = "SELECT l FROM LoaiPhong l ORDER BY l.maLoai DESC")
})
public class LoaiPhong implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MaLoai")
    private Integer maLoai;

    @Column(name = "TenLoai", nullable = false, unique = true, length = 100)
    private String tenLoai;

    @Column(name = "MoTa", length = 300)
    private String moTa;

    @OneToMany(mappedBy = "maLoai")
    private List<Phong> phongList;

    public LoaiPhong() {}

    public Integer getMaLoai() { return maLoai; }
    public void setMaLoai(Integer maLoai) { this.maLoai = maLoai; }
    public String getTenLoai() { return tenLoai; }
    public void setTenLoai(String tenLoai) { this.tenLoai = tenLoai; }
    public String getMoTa() { return moTa; }
    public void setMoTa(String moTa) { this.moTa = moTa; }
    public List<Phong> getPhongList() { return phongList; }
    public void setPhongList(List<Phong> phongList) { this.phongList = phongList; }
}
