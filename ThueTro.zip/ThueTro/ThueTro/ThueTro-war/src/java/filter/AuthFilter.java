package filter;

import ebeans.NguoiDung;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter(filterName = "AuthFilter", urlPatterns = {"/admin/*", "/checkout", "/my-orders"})
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);

        NguoiDung user = (session != null) ? (NguoiDung) session.getAttribute("account") : null;

        if (user == null) {
            res.sendRedirect(req.getContextPath() + "/login?msg=login_required");
            return;
        }

        String uri = req.getRequestURI();
        if (uri.contains("/admin/") && !"ADMIN".equals(user.getVaiTro())) {
            res.sendError(HttpServletResponse.SC_FORBIDDEN, "Bạn không có quyền truy cập trang Quản trị!");
            return;
        }

        chain.doFilter(request, response);
    }
}
