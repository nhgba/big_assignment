package model;

import ebeans.Phong;
import java.io.Serializable;
import java.math.BigDecimal;

public class CartItem implements Serializable {
    private Phong phong;
    private int soThang;

    public CartItem(Phong phong, int soThang) {
        this.phong = phong;
        this.soThang = soThang;
    }

    public Phong getPhong() { return phong; }
    public void setPhong(Phong phong) { this.phong = phong; }
    public int getSoThang() { return soThang; }
    public void setSoThang(int soThang) { this.soThang = soThang; }

    public BigDecimal getThanhTien() {
        if (phong == null || phong.getGiaThue() == null) return BigDecimal.ZERO;
        return phong.getGiaThue().multiply(BigDecimal.valueOf(soThang));
    }
}
