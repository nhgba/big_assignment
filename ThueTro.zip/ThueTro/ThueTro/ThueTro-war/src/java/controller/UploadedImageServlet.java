package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Phục vụ ảnh đã tải lên từ thư mục ngoài ứng dụng.
 * Thư mục lưu: <user.home>/ThueTroUploads
 */
@WebServlet(name = "UploadedImageServlet", urlPatterns = {"/uploaded-images/*"})
public class UploadedImageServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        // getPathInfo() có dạng "/ten-file.jpg"; bỏ dấu "/" đầu tiên trước khi kiểm tra.
        if (pathInfo == null || pathInfo.length() <= 1) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        String fileName = pathInfo.substring(1);
        if (fileName.contains("/") || fileName.contains("\\\\") || fileName.contains("..")) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        Path uploadDir = Paths.get(System.getProperty("user.home"), "ThueTroUploads")
                .toAbsolutePath().normalize();
        Path imagePath = uploadDir.resolve(fileName).normalize();

        if (!imagePath.getParent().equals(uploadDir) || !Files.isRegularFile(imagePath)) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        String lowerName = fileName.toLowerCase(java.util.Locale.ROOT);
        String contentType = lowerName.endsWith(".png") ? "image/png"
                : lowerName.endsWith(".gif") ? "image/gif"
                : lowerName.endsWith(".webp") ? "image/webp"
                : "image/jpeg";
        response.setContentType(contentType);
        response.setContentLengthLong(Files.size(imagePath));
        response.setHeader("X-Content-Type-Options", "nosniff");
        response.setHeader("Cache-Control", "public, max-age=86400");

        try (InputStream input = Files.newInputStream(imagePath);
             java.io.OutputStream output = response.getOutputStream()) {
            byte[] buffer = new byte[8192];
            int length;
            while ((length = input.read(buffer)) != -1) {
                output.write(buffer, 0, length);
            }
        }
    }
}
