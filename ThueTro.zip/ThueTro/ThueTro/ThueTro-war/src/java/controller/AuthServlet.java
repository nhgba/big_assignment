package controller;

import ebeans.NguoiDung;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.Date;
import sbeans.NguoiDungFacadeLocal;
import util.SecurityUtil;

@WebServlet(name = "AuthServlet", urlPatterns = {"/login", "/register", "/logout", "/admin/register-admin"})
public class AuthServlet extends HttpServlet {
    @EJB private NguoiDungFacadeLocal nguoiDungFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();
        if ("/logout".equals(path)) {
            HttpSession session = request.getSession(false);
            if (session != null) session.invalidate();
            response.sendRedirect(request.getContextPath() + "/home");
        } else if ("/register".equals(path)) {
            request.getRequestDispatcher("/views/auth/register.jsp").forward(request, response);
        } else if ("/admin/register-admin".equals(path)) {
            request.getRequestDispatcher("/views/admin/register-admin.jsp").forward(request, response);
        } else {
            request.getRequestDispatcher("/views/auth/login.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        if ("/login".equals(path)) {
            String user = request.getParameter("tenDangNhap");
            String pass = request.getParameter("matKhau");
            NguoiDung acc = nguoiDungFacade.login(user, SecurityUtil.sha256Hex(pass));
            if (acc != null) {
                HttpSession session = request.getSession();
                session.setAttribute("account", acc);
                if ("ADMIN".equals(acc.getVaiTro())) {
                    response.sendRedirect(request.getContextPath() + "/admin/phong");
                } else {
                    response.sendRedirect(request.getContextPath() + "/home");
                }
            } else {
                request.setAttribute("error", "Sai tên đăng nhập hoặc mật khẩu!");
                request.getRequestDispatcher("/views/auth/login.jsp").forward(request, response);
            }
        } else if ("/register".equals(path)) {
            String tenDangNhap = request.getParameter("tenDangNhap").trim();
            String matKhau = request.getParameter("matKhau");
            String xacNhanMK = request.getParameter("xacNhanMK");
            String hoTen = request.getParameter("hoTen").trim();
            String email = request.getParameter("email").trim();
            String sdt = request.getParameter("soDienThoai").trim();

            if (!matKhau.equals(xacNhanMK)) {
                request.setAttribute("error", "Mật khẩu xác nhận không khớp!");
                request.getRequestDispatcher("/views/auth/register.jsp").forward(request, response);
                return;
            }
            if (nguoiDungFacade.existsUsername(tenDangNhap)) {
                request.setAttribute("error", "Tên đăng nhập đã tồn tại!");
                request.getRequestDispatcher("/views/auth/register.jsp").forward(request, response);
                return;
            }
            if (nguoiDungFacade.existsEmail(email)) {
                request.setAttribute("error", "Email đã được sử dụng!");
                request.getRequestDispatcher("/views/auth/register.jsp").forward(request, response);
                return;
            }

            NguoiDung nd = new NguoiDung();
            nd.setTenDangNhap(tenDangNhap);
            nd.setMatKhau(SecurityUtil.sha256Hex(matKhau));
            nd.setHoTen(hoTen);
            nd.setEmail(email);
            nd.setSoDienThoai(sdt);
            nd.setVaiTro("KHACH");
            nd.setNgayTao(new Date());
            nguoiDungFacade.create(nd);

            response.sendRedirect(request.getContextPath() + "/login?msg=register_ok");
        } else if ("/admin/register-admin".equals(path)) {
            HttpSession session = request.getSession(false);
            NguoiDung current = (session != null) ? (NguoiDung) session.getAttribute("account") : null;
            if (current == null || !"ADMIN".equals(current.getVaiTro())) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN, "Bạn không có quyền tạo tài khoản Admin!");
                return;
            }

            String tenDangNhap = request.getParameter("tenDangNhap").trim();
            String matKhau = request.getParameter("matKhau");
            String xacNhanMK = request.getParameter("xacNhanMK");
            String hoTen = request.getParameter("hoTen").trim();
            String email = request.getParameter("email").trim();
            String sdt = request.getParameter("soDienThoai").trim();

            if (!matKhau.equals(xacNhanMK)) {
                request.setAttribute("error", "Mật khẩu xác nhận không khớp!");
                request.getRequestDispatcher("/views/admin/register-admin.jsp").forward(request, response);
                return;
            }
            if (nguoiDungFacade.existsUsername(tenDangNhap)) {
                request.setAttribute("error", "Tên đăng nhập đã tồn tại!");
                request.getRequestDispatcher("/views/admin/register-admin.jsp").forward(request, response);
                return;
            }
            if (nguoiDungFacade.existsEmail(email)) {
                request.setAttribute("error", "Email đã được sử dụng!");
                request.getRequestDispatcher("/views/admin/register-admin.jsp").forward(request, response);
                return;
            }

            NguoiDung nd = new NguoiDung();
            nd.setTenDangNhap(tenDangNhap);
            nd.setMatKhau(SecurityUtil.sha256Hex(matKhau));
            nd.setHoTen(hoTen);
            nd.setEmail(email);
            nd.setSoDienThoai(sdt);
            nd.setVaiTro("ADMIN");
            nd.setNgayTao(new Date());
            nguoiDungFacade.create(nd);
            response.sendRedirect(request.getContextPath() + "/admin/register-admin?success=1");
        }
    }
}
