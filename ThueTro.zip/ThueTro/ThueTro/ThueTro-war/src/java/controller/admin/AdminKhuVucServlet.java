package controller.admin;

import ebeans.KhuVuc;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import sbeans.KhuVucFacadeLocal;

@WebServlet(name = "AdminKhuVucServlet", urlPatterns = {"/admin/khu-vuc"})
public class AdminKhuVucServlet extends HttpServlet {
    @EJB private KhuVucFacadeLocal khuVucFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Phải đặt encoding trước khi đọc bất kỳ query parameter nào (keyword, action, id).
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            try {
                KhuVuc kv = khuVucFacade.find(id);
                if (kv != null) khuVucFacade.remove(kv);
                response.sendRedirect(request.getContextPath() + "/admin/khu-vuc?msg=deleted");
            } catch (Exception e) {
                response.sendRedirect(request.getContextPath() + "/admin/khu-vuc?error=in_use");
            }
            return;
        } else if ("edit".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            request.setAttribute("editItem", khuVucFacade.find(id));
        }

        String keyword = request.getParameter("keyword");
        request.setAttribute("keyword", keyword);
        request.setAttribute("list", khuVucFacade.searchByName(keyword));
        request.getRequestDispatcher("/views/admin/khu-vuc.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String idStr = request.getParameter("maKV");
        String tenKV = request.getParameter("tenKV");
        String moTa = request.getParameter("moTa");

        if (tenKV == null || tenKV.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/admin/khu-vuc?error=empty_name");
            return;
        }

        try {
            if (idStr != null && !idStr.isEmpty()) {
                KhuVuc kv = khuVucFacade.find(Integer.parseInt(idStr));
                kv.setTenKV(tenKV.trim());
                kv.setMoTa(moTa);
                khuVucFacade.edit(kv);
            } else {
                KhuVuc kv = new KhuVuc();
                kv.setTenKV(tenKV.trim());
                kv.setMoTa(moTa);
                khuVucFacade.create(kv);
            }
            response.sendRedirect(request.getContextPath() + "/admin/khu-vuc?msg=saved");
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/khu-vuc?error=duplicate");
        }
    }
}
