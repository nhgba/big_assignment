package controller.admin;

import ebeans.DonThue;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import sbeans.DonThueFacadeLocal;

@WebServlet(name = "AdminDonThueServlet", urlPatterns = {"/admin/don-thue"})
public class AdminDonThueServlet extends HttpServlet {
    @EJB private DonThueFacadeLocal donThueFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String idStr = request.getParameter("id");

        if ("confirm".equals(action) && idStr != null) {
            donThueFacade.xacNhanDonThue(Integer.parseInt(idStr));
            response.sendRedirect(request.getContextPath() + "/admin/don-thue?msg=confirmed");
            return;
        } else if ("cancel".equals(action) && idStr != null) {
            donThueFacade.huyDonThue(Integer.parseInt(idStr));
            response.sendRedirect(request.getContextPath() + "/admin/don-thue?msg=canceled");
            return;
        } else if ("detail".equals(action) && idStr != null) {
            DonThue selectedDon = donThueFacade.find(Integer.parseInt(idStr));
            request.setAttribute("selectedDon", selectedDon);
        }

        request.setAttribute("listDon", donThueFacade.findAllOrderByDate());
        request.getRequestDispatcher("/views/admin/don-thue.jsp").forward(request, response);
    }
}
