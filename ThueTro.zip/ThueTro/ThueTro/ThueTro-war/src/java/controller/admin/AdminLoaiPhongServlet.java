package controller.admin;

import ebeans.LoaiPhong;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import sbeans.LoaiPhongFacadeLocal;

@WebServlet(name = "AdminLoaiPhongServlet", urlPatterns = {"/admin/loai-phong"})
public class AdminLoaiPhongServlet extends HttpServlet {
    @EJB private LoaiPhongFacadeLocal loaiPhongFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            try {
                LoaiPhong lp = loaiPhongFacade.find(id);
                if (lp != null) loaiPhongFacade.remove(lp);
                response.sendRedirect(request.getContextPath() + "/admin/loai-phong?msg=deleted");
            } catch (Exception e) {
                response.sendRedirect(request.getContextPath() + "/admin/loai-phong?error=in_use");
            }
            return;
        } else if ("edit".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            request.setAttribute("editItem", loaiPhongFacade.find(id));
        }

        String keyword = request.getParameter("keyword");
        request.setAttribute("keyword", keyword);
        request.setAttribute("list", loaiPhongFacade.searchByName(keyword));
        request.getRequestDispatcher("/views/admin/loai-phong.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String idStr = request.getParameter("maLoai");
        String tenLoai = request.getParameter("tenLoai");
        String moTa = request.getParameter("moTa");

        if (tenLoai == null || tenLoai.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/admin/loai-phong?error=empty_name");
            return;
        }

        try {
            if (idStr != null && !idStr.isEmpty()) {
                LoaiPhong lp = loaiPhongFacade.find(Integer.parseInt(idStr));
                lp.setTenLoai(tenLoai.trim());
                lp.setMoTa(moTa);
                loaiPhongFacade.edit(lp);
            } else {
                LoaiPhong lp = new LoaiPhong();
                lp.setTenLoai(tenLoai.trim());
                lp.setMoTa(moTa);
                loaiPhongFacade.create(lp);
            }
            response.sendRedirect(request.getContextPath() + "/admin/loai-phong?msg=saved");
        } catch (Exception e) {
            response.sendRedirect(request.getContextPath() + "/admin/loai-phong?error=duplicate");
        }
    }
}
