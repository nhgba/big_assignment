package controller.admin;

import ebeans.Phong;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.Part;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.UUID;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import sbeans.KhuVucFacadeLocal;
import sbeans.LoaiPhongFacadeLocal;
import sbeans.PhongFacadeLocal;

@WebServlet(name = "AdminPhongServlet", urlPatterns = {"/admin/phong"})
@MultipartConfig(maxFileSize = 5 * 1024 * 1024, maxRequestSize = 6 * 1024 * 1024)
public class AdminPhongServlet extends HttpServlet {
    @EJB private PhongFacadeLocal phongFacade;
    @EJB private KhuVucFacadeLocal khuVucFacade;
    @EJB private LoaiPhongFacadeLocal loaiPhongFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("delete".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            try {
                Phong p = phongFacade.find(id);
                if (p != null) phongFacade.remove(p);
                response.sendRedirect(request.getContextPath() + "/admin/phong?msg=deleted");
            } catch (Exception e) {
                response.sendRedirect(request.getContextPath() + "/admin/phong?error=in_use");
            }
            return;
        } else if ("edit".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            request.setAttribute("editItem", phongFacade.find(id));
        }

        String keyword = request.getParameter("keyword");
        String trangThai = request.getParameter("trangThai");

        request.setAttribute("keyword", keyword);
        request.setAttribute("trangThai", trangThai);
        request.setAttribute("list", phongFacade.searchPhong(keyword, null, null, trangThai));
        request.setAttribute("listKV", khuVucFacade.findAll());
        request.setAttribute("listLoai", loaiPhongFacade.findAll());

        request.getRequestDispatcher("/views/admin/phong.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        try {
            // Phải đọc multipart Part ngay đầu request, trước khi đọc các field thường.
            // Điều này tránh một số trường hợp container parse multipart không đúng thứ tự.
            if (request.getContentType() == null
                    || !request.getContentType().toLowerCase(Locale.ROOT).startsWith("multipart/form-data")) {
                throw new ServletException("Form chưa gửi multipart/form-data. Kiểm tra enctype của form.");
            }
            Part imagePart = request.getPart("hinhAnhFile");

            String idStr = request.getParameter("maPhong");
            String tenPhong = request.getParameter("tenPhong");
            int maKV = Integer.parseInt(request.getParameter("maKV"));
            int maLoai = Integer.parseInt(request.getParameter("maLoai"));
            String diaChi = request.getParameter("diaChi");
            BigDecimal dienTich = new BigDecimal(request.getParameter("dienTich"));
            BigDecimal giaThue = new BigDecimal(request.getParameter("giaThue"));
            String moTa = request.getParameter("moTa");
            String trangThai = request.getParameter("trangThai");

            if (dienTich.compareTo(BigDecimal.ZERO) <= 0 || giaThue.compareTo(BigDecimal.ZERO) <= 0) {
                response.sendRedirect(request.getContextPath() + "/admin/phong?error=invalid_number");
                return;
            }

            Phong p = (idStr != null && !idStr.isEmpty()) ? phongFacade.find(Integer.parseInt(idStr)) : new Phong();
            if (p == null) {
                response.sendRedirect(request.getContextPath() + "/admin/phong?error=not_found");
                return;
            }

            // Nếu người dùng chọn ảnh mới thì lưu ảnh vào thư mục riêng, ổn định ngoài thư mục deploy.
            // Nếu không chọn ảnh khi cập nhật, giữ nguyên ảnh đang có.
            if (imagePart != null && imagePart.getSize() > 0) {
                String submittedName = imagePart.getSubmittedFileName();
                if (submittedName == null || submittedName.trim().isEmpty()) {
                    throw new ServletException("Không đọc được tên file ảnh được chọn.");
                }
                String extension = "";
                if (submittedName != null && submittedName.lastIndexOf('.') >= 0) {
                    extension = submittedName.substring(submittedName.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT);
                }
                if (!("jpg".equals(extension) || "jpeg".equals(extension) || "png".equals(extension)
                        || "gif".equals(extension) || "webp".equals(extension))) {
                    response.sendRedirect(request.getContextPath() + "/admin/phong?error=invalid_image");
                    return;
                }
                String contentType = imagePart.getContentType();
                if (contentType == null || !contentType.toLowerCase(Locale.ROOT).startsWith("image/")) {
                    response.sendRedirect(request.getContextPath() + "/admin/phong?error=invalid_image");
                    return;
                }
                String savedName = UUID.randomUUID().toString() + "." + extension;

                // Lưu ảnh ngoài thư mục deploy của GlassFish để tránh mất ảnh khi redeploy.
                // Thư mục mặc định: <user.home>/ThueTroUploads
                String userHome = System.getProperty("user.home");
                if (userHome == null || userHome.trim().isEmpty()) {
                    throw new IOException("Không xác định được thư mục home để lưu ảnh.");
                }
                Path uploadDir = Paths.get(userHome, "ThueTroUploads").toAbsolutePath().normalize();
                Files.createDirectories(uploadDir);

                Path destination = uploadDir.resolve(savedName).normalize();
                if (!destination.getParent().equals(uploadDir)) {
                    throw new IOException("Đường dẫn lưu ảnh không hợp lệ.");
                }
                try (java.io.InputStream input = imagePart.getInputStream()) {
                    Files.copy(input, destination, StandardCopyOption.REPLACE_EXISTING);
                }
                if (!Files.isRegularFile(destination) || Files.size(destination) == 0) {
                    throw new IOException("File ảnh không được ghi thành công: " + destination);
                }
                log("Đã upload ảnh phòng: " + destination + " (" + Files.size(destination) + " bytes)");
                // Ảnh được phục vụ thông qua UploadedImageServlet.
                p.setHinhAnh("uploaded-images/" + savedName);
            }

            p.setTenPhong(tenPhong.trim());
            p.setMaKV(khuVucFacade.find(maKV));
            p.setMaLoai(loaiPhongFacade.find(maLoai));
            p.setDiaChi(diaChi.trim());
            p.setDienTich(dienTich);
            p.setGiaThue(giaThue);
            p.setMoTa(moTa);
            p.setTrangThai(trangThai != null ? trangThai : "CON");

            if (idStr != null && !idStr.isEmpty()) {
                phongFacade.edit(p);
            } else {
                p.setNgayDang(new Date());
                phongFacade.create(p);
            }
            response.sendRedirect(request.getContextPath() + "/admin/phong?msg=saved");
        } catch (Exception e) {
            log("Lỗi khi thêm/cập nhật phòng hoặc tải ảnh lên", e);
            String error = (e instanceof jakarta.servlet.ServletException
                    || e instanceof IOException) ? "upload_failed" : "invalid_input";
            response.sendRedirect(request.getContextPath() + "/admin/phong?error=" + error);
        }
    }
}
