package controller;

import ebeans.GopY;
import ebeans.NguoiDung;
import ebeans.Phong;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import sbeans.GopYFacadeLocal;
import sbeans.PhongFacadeLocal;

@WebServlet(name = "RoomDetailServlet", urlPatterns = {"/room-detail"})
public class RoomDetailServlet extends HttpServlet {
    @EJB private PhongFacadeLocal phongFacade;
    @EJB private GopYFacadeLocal gopYFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idStr = request.getParameter("id");
        if (idStr == null || idStr.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/home");
            return;
        }
        int id = Integer.parseInt(idStr);
        Phong phong = phongFacade.find(id);
        if (phong == null) {
            response.sendRedirect(request.getContextPath() + "/home");
            return;
        }
        List<GopY> listGopY = gopYFacade.findByPhong(id);
        request.setAttribute("phong", phong);
        request.setAttribute("listGopY", listGopY);
        request.getRequestDispatcher("/views/client/room-detail.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        int maPhong = Integer.parseInt(request.getParameter("maPhong"));
        String hoTen = request.getParameter("hoTen");
        String email = request.getParameter("email");
        String noiDung = request.getParameter("noiDung");

        Phong phong = phongFacade.find(maPhong);
        if (phong != null && noiDung != null && !noiDung.trim().isEmpty()) {
            GopY gy = new GopY();
            gy.setMaPhong(phong);
            HttpSession session = request.getSession(false);
            NguoiDung acc = (session != null) ? (NguoiDung) session.getAttribute("account") : null;
            if (acc != null) {
                gy.setMaND(acc);
                gy.setHoTen(acc.getHoTen());
                gy.setEmail(acc.getEmail());
            } else {
                gy.setHoTen(hoTen != null && !hoTen.trim().isEmpty() ? hoTen.trim() : "Khách ẩn danh");
                gy.setEmail(email);
            }
            gy.setNoiDung(noiDung.trim());
            gy.setNgayGui(new Date());
            gopYFacade.create(gy);
        }
        response.sendRedirect(request.getContextPath() + "/room-detail?id=" + maPhong + "&msg=feedback_ok");
    }
}
