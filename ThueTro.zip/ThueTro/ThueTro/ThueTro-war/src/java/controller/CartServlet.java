package controller;

import ebeans.Phong;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;
import model.CartItem;
import sbeans.PhongFacadeLocal;

@WebServlet(name = "CartServlet", urlPatterns = {"/cart"})
public class CartServlet extends HttpServlet {
    @EJB private PhongFacadeLocal phongFacade;

    @SuppressWarnings("unchecked")
    private Map<Integer, CartItem> getCart(HttpSession session) {
        Map<Integer, CartItem> cart = (Map<Integer, CartItem>) session.getAttribute("cart");
        if (cart == null) {
            cart = new LinkedHashMap<>();
            session.setAttribute("cart", cart);
        }
        return cart;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        Map<Integer, CartItem> cart = getCart(session);

        if ("add".equals(action)) {
            int maPhong = Integer.parseInt(request.getParameter("id"));
            int soThang = 1;
            try {
                soThang = Integer.parseInt(request.getParameter("soThang"));
                if (soThang < 1) soThang = 1;
            } catch (Exception ignored) {}

            Phong p = phongFacade.find(maPhong);
            if (p != null && "CON".equals(p.getTrangThai())) {
                if (cart.containsKey(maPhong)) {
                    CartItem item = cart.get(maPhong);
                    item.setSoThang(item.getSoThang() + soThang);
                } else {
                    cart.put(maPhong, new CartItem(p, soThang));
                }
            }
            response.sendRedirect(request.getContextPath() + "/cart");
            return;
        } else if ("remove".equals(action)) {
            int maPhong = Integer.parseInt(request.getParameter("id"));
            cart.remove(maPhong);
            response.sendRedirect(request.getContextPath() + "/cart");
            return;
        }

        BigDecimal tongTien = BigDecimal.ZERO;
        for (CartItem item : cart.values()) {
            tongTien = tongTien.add(item.getThanhTien());
        }
        request.setAttribute("tongTien", tongTien);
        request.getRequestDispatcher("/views/client/cart.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Map<Integer, CartItem> cart = getCart(session);
        String action = request.getParameter("action");

        if ("update".equals(action)) {
            int maPhong = Integer.parseInt(request.getParameter("maPhong"));
            int soThang = Integer.parseInt(request.getParameter("soThang"));
            if (cart.containsKey(maPhong)) {
                if (soThang > 0) {
                    cart.get(maPhong).setSoThang(soThang);
                } else {
                    cart.remove(maPhong);
                }
            }
        }
        response.sendRedirect(request.getContextPath() + "/cart");
    }
}
