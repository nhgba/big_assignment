package controller;

import ebeans.KhuVuc;
import ebeans.LoaiPhong;
import ebeans.Phong;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;
import sbeans.KhuVucFacadeLocal;
import sbeans.LoaiPhongFacadeLocal;
import sbeans.PhongFacadeLocal;

@WebServlet(name = "HomeServlet", urlPatterns = {"/home", ""})
public class HomeServlet extends HttpServlet {
    @EJB private PhongFacadeLocal phongFacade;
    @EJB private KhuVucFacadeLocal khuVucFacade;
    @EJB private LoaiPhongFacadeLocal loaiPhongFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String keyword = request.getParameter("keyword");
        String maKVStr = request.getParameter("maKV");
        String maLoaiStr = request.getParameter("maLoai");

        Integer maKV = (maKVStr != null && !maKVStr.isEmpty()) ? Integer.parseInt(maKVStr) : null;
        Integer maLoai = (maLoaiStr != null && !maLoaiStr.isEmpty()) ? Integer.parseInt(maLoaiStr) : null;

        List<Phong> listPhong = phongFacade.searchPhong(keyword, maKV, maLoai, "CON");
        List<KhuVuc> listKV = khuVucFacade.findAll();
        List<LoaiPhong> listLoai = loaiPhongFacade.findAll();

        request.setAttribute("listPhong", listPhong);
        request.setAttribute("listKV", listKV);
        request.setAttribute("listLoai", listLoai);
        request.setAttribute("keyword", keyword);
        request.setAttribute("selectedKV", maKV);
        request.setAttribute("selectedLoai", maLoai);

        request.getRequestDispatcher("/views/client/home.jsp").forward(request, response);
    }
}
