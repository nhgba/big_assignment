package controller;

import ebeans.ChiTietDonThue;
import ebeans.DonThue;
import ebeans.NguoiDung;
import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import model.CartItem;
import sbeans.DonThueFacadeLocal;

@WebServlet(name = "CheckoutServlet", urlPatterns = {"/checkout", "/my-orders"})
public class CheckoutServlet extends HttpServlet {
    @EJB private DonThueFacadeLocal donThueFacade;

    @Override
    @SuppressWarnings("unchecked")
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getServletPath();
        HttpSession session = request.getSession();
        NguoiDung acc = (NguoiDung) session.getAttribute("account");

        if ("/my-orders".equals(path)) {
            List<DonThue> orders = donThueFacade.findByUser(acc.getMaND());
            request.setAttribute("orders", orders);
            request.getRequestDispatcher("/views/client/my-orders.jsp").forward(request, response);
            return;
        }

        Map<Integer, CartItem> cart = (Map<Integer, CartItem>) session.getAttribute("cart");
        if (cart == null || cart.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/cart");
            return;
        }

        BigDecimal tongTien = BigDecimal.ZERO;
        for (CartItem item : cart.values()) {
            tongTien = tongTien.add(item.getThanhTien());
        }
        request.setAttribute("tongTien", tongTien);
        request.getRequestDispatcher("/views/client/checkout.jsp").forward(request, response);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();
        NguoiDung acc = (NguoiDung) session.getAttribute("account");
        Map<Integer, CartItem> cart = (Map<Integer, CartItem>) session.getAttribute("cart");

        if (cart == null || cart.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/cart");
            return;
        }

        String hoTenNguoiThue = request.getParameter("hoTenNguoiThue");
        String soDienThoai = request.getParameter("soDienThoai");
        String diaChiLienHe = request.getParameter("diaChiLienHe");
        String phuongThucTT = request.getParameter("phuongThucTT");
        String ghiChu = request.getParameter("ghiChu");

        DonThue don = new DonThue();
        don.setMaND(acc);
        don.setNgayDat(new Date());
        don.setHoTenNguoiThue(hoTenNguoiThue);
        don.setSoDienThoai(soDienThoai);
        don.setDiaChiLienHe(diaChiLienHe);
        don.setPhuongThucTT(phuongThucTT);
        don.setGhiChu(ghiChu);
        don.setTrangThai("CHOXACNHAN");

        BigDecimal tongTien = BigDecimal.ZERO;
        List<ChiTietDonThue> listCT = new ArrayList<>();
        for (CartItem item : cart.values()) {
            ChiTietDonThue ct = new ChiTietDonThue();
            ct.setMaDon(don);
            ct.setMaPhong(item.getPhong());
            ct.setSoThang(item.getSoThang());
            ct.setDonGia(item.getPhong().getGiaThue());
            tongTien = tongTien.add(item.getThanhTien());
            listCT.add(ct);
        }
        don.setTongTien(tongTien);
        don.setChiTietDonThueList(listCT);

        donThueFacade.create(don);
        session.removeAttribute("cart");

        response.sendRedirect(request.getContextPath() + "/my-orders?msg=order_success");
    }
}
