package mbeans;

import ebeans.ChiTietDonThue;
import ebeans.DonThue;
import ebeans.Phong;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import model.CartItem;
import sbeans.DonThueFacadeLocal;
import sbeans.PhongFacadeLocal;

@Named("cartMB")
@SessionScoped
public class CartMB implements Serializable {
    private static final long serialVersionUID = 1L;

    @EJB
    private PhongFacadeLocal phongFacade;
    @EJB
    private DonThueFacadeLocal donThueFacade;

    @Inject
    private AuthMB authMB;

    private List<CartItem> items = new ArrayList<>();
    private DonThue donThue = new DonThue();

    public String addToCart(Integer maPhong, int soThang) {
        Phong p = phongFacade.find(maPhong);
        if (p == null || !"CON".equals(p.getTrangThai())) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_WARN, "Phòng không khả dụng để đặt!", null));
            return null;
        }
        for (CartItem item : items) {
            if (item.getPhong().getMaPhong().equals(maPhong)) {
                item.setSoThang(item.getSoThang() + Math.max(1, soThang));
                return "/views/client/cart.xhtml?faces-redirect=true";
            }
        }
        items.add(new CartItem(p, Math.max(1, soThang)));
        return "/views/client/cart.xhtml?faces-redirect=true";
    }

    public void removeItem(Integer maPhong) {
        items.removeIf(item -> item.getPhong().getMaPhong().equals(maPhong));
    }

    public BigDecimal getTongTien() {
        BigDecimal total = BigDecimal.ZERO;
        for (CartItem item : items) {
            total = total.add(item.getThanhTien());
        }
        return total;
    }

    public String checkout() {
        if (authMB == null || !authMB.isLoggedIn()) {
            return "/views/auth/login.xhtml?faces-redirect=true";
        }
        if (items.isEmpty()) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_WARN, "Giỏ đặt phòng đang trống!", null));
            return null;
        }

        donThue.setMaND(authMB.getCurrentUser());
        donThue.setNgayDat(new Date());
        donThue.setTongTien(getTongTien());
        donThue.setTrangThai("CHOXACNHAN");

        List<ChiTietDonThue> chiTietList = new ArrayList<>();
        for (CartItem item : items) {
            ChiTietDonThue ct = new ChiTietDonThue();
            ct.setMaDon(donThue);
            ct.setMaPhong(item.getPhong());
            ct.setSoThang(item.getSoThang());
            ct.setDonGia(item.getPhong().getGiaThue());
            chiTietList.add(ct);
        }
        donThue.setChiTietDonThueList(chiTietList);
        donThueFacade.create(donThue);

        items.clear();
        donThue = new DonThue();
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_INFO, "Đặt phòng thành công!", null));
        return "/views/client/my-orders.xhtml?faces-redirect=true";
    }

    public List<CartItem> getItems() { return items; }
    public DonThue getDonThue() { return donThue; }
    public void setDonThue(DonThue donThue) { this.donThue = donThue; }
}
