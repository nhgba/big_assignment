package mbeans;

import ebeans.GopY;
import ebeans.Phong;
import jakarta.ejb.EJB;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import sbeans.GopYFacadeLocal;
import sbeans.PhongFacadeLocal;

@Named("roomDetailMB")
@ViewScoped
public class RoomDetailMB implements Serializable {
    private static final long serialVersionUID = 1L;

    @EJB
    private PhongFacadeLocal phongFacade;
    @EJB
    private GopYFacadeLocal gopYFacade;

    @Inject
    private AuthMB authMB;

    private Integer maPhong;
    private Phong phong;
    private GopY newGopY = new GopY();

    public void loadPhong() {
        if (maPhong != null) {
            phong = phongFacade.find(maPhong);
        }
    }

    public List<GopY> getDanhSachGopY() {
        if (maPhong == null) return null;
        return gopYFacade.findByPhong(maPhong);
    }

    public void guiGopY() {
        if (phong == null) return;
        newGopY.setMaPhong(phong);
        newGopY.setNgayGui(new Date());
        if (authMB != null && authMB.isLoggedIn()) {
            newGopY.setMaND(authMB.getCurrentUser());
            if (newGopY.getHoTen() == null || newGopY.getHoTen().isEmpty()) {
                newGopY.setHoTen(authMB.getCurrentUser().getHoTen());
            }
            if (newGopY.getEmail() == null || newGopY.getEmail().isEmpty()) {
                newGopY.setEmail(authMB.getCurrentUser().getEmail());
            }
        }
        gopYFacade.create(newGopY);
        newGopY = new GopY();
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_INFO, "Cảm ơn bạn đã gửi góp ý!", null));
    }

    public Integer getMaPhong() { return maPhong; }
    public void setMaPhong(Integer maPhong) { this.maPhong = maPhong; }
    public Phong getPhong() { return phong; }
    public GopY getNewGopY() { return newGopY; }
    public void setNewGopY(GopY newGopY) { this.newGopY = newGopY; }
}
