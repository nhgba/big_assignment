package mbeans;

import ebeans.DonThue;
import jakarta.ejb.EJB;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.List;
import sbeans.DonThueFacadeLocal;

@Named("donThueMB")
@ViewScoped
public class DonThueMB implements Serializable {
    private static final long serialVersionUID = 1L;

    @EJB
    private DonThueFacadeLocal donThueFacade;

    @Inject
    private AuthMB authMB;

    // Dùng cho Admin quản lý tất cả đơn thuê
    public List<DonThue> getAllDonThue() {
        return donThueFacade.findAllOrderByDate();
    }

    // Dùng cho Khách xem đơn thuê của mình
    public List<DonThue> getMyOrders() {
        if (authMB == null || !authMB.isLoggedIn()) return null;
        return donThueFacade.findByUser(authMB.getCurrentUser().getMaND());
    }

    public void xacNhan(Integer maDon) {
        donThueFacade.xacNhanDonThue(maDon);
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_INFO, "Đã xác nhận đơn thuê #" + maDon, null));
    }

    public void huyDon(Integer maDon) {
        donThueFacade.huyDonThue(maDon);
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_WARN, "Đã hủy đơn thuê #" + maDon, null));
    }
}
