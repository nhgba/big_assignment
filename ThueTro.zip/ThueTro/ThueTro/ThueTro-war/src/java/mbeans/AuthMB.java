package mbeans;

import ebeans.NguoiDung;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.Date;
import sbeans.NguoiDungFacadeLocal;
import util.SecurityUtil;

@Named("authMB")
@SessionScoped
public class AuthMB implements Serializable {
    private static final long serialVersionUID = 1L;

    @EJB
    private NguoiDungFacadeLocal nguoiDungFacade;

    private String tenDangNhap;
    private String matKhau;
    private NguoiDung currentUser;
    private NguoiDung newUser = new NguoiDung();
    private String confirmPassword;

    public String login() {
        String hash = SecurityUtil.sha256Hex(matKhau);
        NguoiDung user = nguoiDungFacade.login(tenDangNhap, hash);
        if (user != null) {
            currentUser = user;
            if ("ADMIN".equalsIgnoreCase(user.getVaiTro())) {
                return "/views/admin/phong.xhtml?faces-redirect=true";
            }
            return "/views/client/home.xhtml?faces-redirect=true";
        }
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_ERROR, "Tên đăng nhập hoặc mật khẩu không đúng!", null));
        return null;
    }

    public String register() {
        if (nguoiDungFacade.existsUsername(newUser.getTenDangNhap())) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Tên đăng nhập đã tồn tại!", null));
            return null;
        }
        if (nguoiDungFacade.existsEmail(newUser.getEmail())) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Email đã được sử dụng!", null));
            return null;
        }
        if (confirmPassword != null && !confirmPassword.equals(newUser.getMatKhau())) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Mật khẩu xác nhận không khớp!", null));
            return null;
        }
        newUser.setMatKhau(SecurityUtil.sha256Hex(newUser.getMatKhau()));
        newUser.setVaiTro("KHACH");
        newUser.setNgayTao(new Date());
        nguoiDungFacade.create(newUser);

        newUser = new NguoiDung();
        confirmPassword = null;
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_INFO, "Đăng ký thành công! Vui lòng đăng nhập.", null));
        return "/views/auth/login.xhtml?faces-redirect=true";
    }

    public String logout() {
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        currentUser = null;
        return "/views/auth/login.xhtml?faces-redirect=true";
    }

    public boolean isLoggedIn() {
        return currentUser != null;
    }

    public boolean isAdmin() {
        return currentUser != null && "ADMIN".equalsIgnoreCase(currentUser.getVaiTro());
    }

    public String getTenDangNhap() { return tenDangNhap; }
    public void setTenDangNhap(String tenDangNhap) { this.tenDangNhap = tenDangNhap; }
    public String getMatKhau() { return matKhau; }
    public void setMatKhau(String matKhau) { this.matKhau = matKhau; }
    public NguoiDung getCurrentUser() { return currentUser; }
    public void setCurrentUser(NguoiDung currentUser) { this.currentUser = currentUser; }
    public NguoiDung getNewUser() { return newUser; }
    public void setNewUser(NguoiDung newUser) { this.newUser = newUser; }
    public String getConfirmPassword() { return confirmPassword; }
    public void setConfirmPassword(String confirmPassword) { this.confirmPassword = confirmPassword; }
}
