package mbeans;

import ebeans.KhuVuc;
import ebeans.LoaiPhong;
import ebeans.Phong;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.EJB;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import sbeans.KhuVucFacadeLocal;
import sbeans.LoaiPhongFacadeLocal;
import sbeans.PhongFacadeLocal;

@Named("phongMB")
@ViewScoped
public class PhongMB implements Serializable {
    private static final long serialVersionUID = 1L;

    @EJB
    private PhongFacadeLocal phongFacade;
    @EJB
    private KhuVucFacadeLocal khuVucFacade;
    @EJB
    private LoaiPhongFacadeLocal loaiPhongFacade;

    private List<Phong> listPhong;
    private Phong phong = new Phong();
    private Integer selectedMaKV;
    private Integer selectedMaLoai;

    // Filter fields
    private String keyword;
    private Integer filterMaKV;
    private Integer filterMaLoai;
    private String filterTrangThai;

    private boolean editing = false;

    @PostConstruct
    public void init() {
        search();
    }

    public void search() {
        listPhong = phongFacade.searchPhong(keyword, filterMaKV, filterMaLoai, filterTrangThai);
    }

    public List<KhuVuc> getAllKhuVuc() {
        return khuVucFacade.findAll();
    }

    public List<LoaiPhong> getAllLoaiPhong() {
        return loaiPhongFacade.findAll();
    }

    public void save() {
        if (selectedMaKV != null) {
            phong.setMaKV(khuVucFacade.find(selectedMaKV));
        }
        if (selectedMaLoai != null) {
            phong.setMaLoai(loaiPhongFacade.find(selectedMaLoai));
        }
        if (editing) {
            phongFacade.edit(phong);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Cập nhật phòng trọ thành công!", null));
        } else {
            phong.setNgayDang(new Date());
            phongFacade.create(phong);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Thêm phòng trọ thành công!", null));
        }
        resetForm();
        search();
    }

    public void editItem(Phong p) {
        this.phong = p;
        this.selectedMaKV = (p.getMaKV() != null) ? p.getMaKV().getMaKV() : null;
        this.selectedMaLoai = (p.getMaLoai() != null) ? p.getMaLoai().getMaLoai() : null;
        this.editing = true;
    }

    public void deleteItem(Phong p) {
        phongFacade.remove(p);
        search();
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_INFO, "Đã xóa phòng trọ!", null));
    }

    public void resetForm() {
        this.phong = new Phong();
        this.selectedMaKV = null;
        this.selectedMaLoai = null;
        this.editing = false;
    }

    public List<Phong> getListPhong() { return listPhong; }
    public Phong getPhong() { return phong; }
    public void setPhong(Phong phong) { this.phong = phong; }
    public Integer getSelectedMaKV() { return selectedMaKV; }
    public void setSelectedMaKV(Integer selectedMaKV) { this.selectedMaKV = selectedMaKV; }
    public Integer getSelectedMaLoai() { return selectedMaLoai; }
    public void setSelectedMaLoai(Integer selectedMaLoai) { this.selectedMaLoai = selectedMaLoai; }
    public String getKeyword() { return keyword; }
    public void setKeyword(String keyword) { this.keyword = keyword; }
    public Integer getFilterMaKV() { return filterMaKV; }
    public void setFilterMaKV(Integer filterMaKV) { this.filterMaKV = filterMaKV; }
    public Integer getFilterMaLoai() { return filterMaLoai; }
    public void setFilterMaLoai(Integer filterMaLoai) { this.filterMaLoai = filterMaLoai; }
    public String getFilterTrangThai() { return filterTrangThai; }
    public void setFilterTrangThai(String filterTrangThai) { this.filterTrangThai = filterTrangThai; }
    public boolean isEditing() { return editing; }
}
