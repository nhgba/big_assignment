package mbeans;

import ebeans.LoaiPhong;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.EJB;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.List;
import sbeans.LoaiPhongFacadeLocal;

@Named("loaiPhongMB")
@ViewScoped
public class LoaiPhongMB implements Serializable {
    private static final long serialVersionUID = 1L;

    @EJB
    private LoaiPhongFacadeLocal loaiPhongFacade;

    private List<LoaiPhong> listLoaiPhong;
    private LoaiPhong loaiPhong = new LoaiPhong();
    private String keyword;
    private boolean editing = false;

    @PostConstruct
    public void init() {
        loadData();
    }

    public void loadData() {
        listLoaiPhong = loaiPhongFacade.searchByName(keyword);
    }

    public void save() {
        if (editing) {
            loaiPhongFacade.edit(loaiPhong);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Cập nhật loại phòng thành công!", null));
        } else {
            loaiPhongFacade.create(loaiPhong);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Thêm loại phòng thành công!", null));
        }
        resetForm();
        loadData();
    }

    public void editItem(LoaiPhong item) {
        this.loaiPhong = item;
        this.editing = true;
    }

    public void deleteItem(LoaiPhong item) {
        loaiPhongFacade.remove(item);
        loadData();
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_INFO, "Đã xóa loại phòng!", null));
    }

    public void resetForm() {
        this.loaiPhong = new LoaiPhong();
        this.editing = false;
    }

    public List<LoaiPhong> getListLoaiPhong() { return listLoaiPhong; }
    public LoaiPhong getLoaiPhong() { return loaiPhong; }
    public void setLoaiPhong(LoaiPhong loaiPhong) { this.loaiPhong = loaiPhong; }
    public String getKeyword() { return keyword; }
    public void setKeyword(String keyword) { this.keyword = keyword; }
    public boolean isEditing() { return editing; }
}
