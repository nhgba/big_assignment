package mbeans;

import ebeans.KhuVuc;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.EJB;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.List;
import sbeans.KhuVucFacadeLocal;

@Named("khuVucMB")
@ViewScoped
public class KhuVucMB implements Serializable {
    private static final long serialVersionUID = 1L;

    @EJB
    private KhuVucFacadeLocal khuVucFacade;

    private List<KhuVuc> listKhuVuc;
    private KhuVuc khuVuc = new KhuVuc();
    private String keyword;
    private boolean editing = false;

    @PostConstruct
    public void init() {
        loadData();
    }

    public void loadData() {
        listKhuVuc = khuVucFacade.searchByName(keyword);
    }

    public void save() {
        if (editing) {
            khuVucFacade.edit(khuVuc);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Cập nhật khu vực thành công!", null));
        } else {
            khuVucFacade.create(khuVuc);
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Thêm khu vực thành công!", null));
        }
        resetForm();
        loadData();
    }

    public void editItem(KhuVuc item) {
        this.khuVuc = item;
        this.editing = true;
    }

    public void deleteItem(KhuVuc item) {
        khuVucFacade.remove(item);
        loadData();
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_INFO, "Đã xóa khu vực!", null));
    }

    public void resetForm() {
        this.khuVuc = new KhuVuc();
        this.editing = false;
    }

    public List<KhuVuc> getListKhuVuc() { return listKhuVuc; }
    public KhuVuc getKhuVuc() { return khuVuc; }
    public void setKhuVuc(KhuVuc khuVuc) { this.khuVuc = khuVuc; }
    public String getKeyword() { return keyword; }
    public void setKeyword(String keyword) { this.keyword = keyword; }
    public boolean isEditing() { return editing; }
}
